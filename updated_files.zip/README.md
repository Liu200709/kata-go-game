# KataGo围棋人机对弈程序

这是一个基于KataGo的围棋人机对弈程序，使用Flask作为后端，HTML/CSS/JavaScript作为前端。

## 功能特点

- 19x19标准围棋棋盘
- 人机对弈（人类执黑，KataGo执白）
- 实时落子反馈
- 棋盘重置功能

## 环境要求

- Python 3.6+
- Flask
- KataGo引擎（可选，当前使用模拟实现）

## 安装步骤

1. 克隆项目到本地

2. 安装依赖
   ```bash
   pip install flask
   ```

3. 下载KataGo引擎和神经网络模型
   - 从 [KataGo Releases](https://github.com/lightvector/KataGo/releases) 下载预编译的KataGo引擎
   - 从 [katagotraining.org](https://katagotraining.org/) 下载最新的神经网络模型

4. 配置KataGo
   - 将下载的KataGo引擎放在项目根目录
   - 将神经网络模型重命名为 `default_model.bin.gz` 并放在项目根目录
   - 复制 `KataGo-master/cpp/configs/gtp_example.cfg` 到项目根目录并重命名为 `default_gtp.cfg`

5. 修改 `main.py` 中的KataGo启动命令，取消注释相关代码

## 运行程序

```bash
python main.py
```

然后在浏览器中访问 `http://localhost:5000`

## 项目结构

```
Project_six/
├── main.py          # Flask应用主文件
├── templates/
│   └── index.html   # 前端界面
├── README.md        # 项目说明
├── katago.exe       # KataGo引擎（需要下载）
├── default_model.bin.gz  # 神经网络模型（需要下载）
└── default_gtp.cfg  # KataGo配置文件（需要复制）
```

## 使用说明

1. 点击棋盘落子，黑棋为人类玩家
2. 系统会自动让KataGo（白棋）落子
3. 点击「重置棋盘」按钮可以重新开始游戏

## 注意事项

- 当前版本使用模拟的KataGo响应，实际使用时需要下载真实的KataGo引擎和模型
- 真实的KataGo引擎需要GPU支持才能获得最佳性能
- 首次运行KataGo时会进行OpenCL调优，可能需要几分钟时间
