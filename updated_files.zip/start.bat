@echo off

echo 正在启动KataGo围棋人机对弈程序...
echo 请确保已安装Python 3.6+
echo 正在启动服务器...
python main.py

pause
